package co.edu.unbosque.lagenericaGr38;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LagenericaGr38Application {

	public static void main(String[] args) {
		SpringApplication.run(LagenericaGr38Application.class, args);
	}

}
