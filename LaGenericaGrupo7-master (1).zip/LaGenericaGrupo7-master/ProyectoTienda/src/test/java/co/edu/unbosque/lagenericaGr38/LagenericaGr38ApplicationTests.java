package co.edu.unbosque.lagenericaGr38;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LagenericaGr38ApplicationTests {

	@Test
	void contextLoads() {
	}

}
