package co.edu.lagenerica;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LagenericaApplicationTests {

	@Test
	void contextLoads() {
	}

}
